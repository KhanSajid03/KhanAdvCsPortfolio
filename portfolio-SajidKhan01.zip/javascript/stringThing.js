function setup() {
  var canvas = createCanvas(480, 120);
}

function draw() {
 fill(0);
	rect(-1,-1,481,121);
	fill(50);
	rect(-1,20,481,121);
	fill(100);
	rect(-1,40,481,121);
	fill(150);
	rect(-1,60,481,121);
	fill(200);
	rect(-1,80,481,121);
	fill(250);
	rect(-1,100,481,121);
	fill(255);
	textSize(32);
	text("Advanced Computer Science",30,60);
	
}